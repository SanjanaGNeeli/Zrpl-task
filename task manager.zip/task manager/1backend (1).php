<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "test";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}

$fname = mysqli_real_escape_string($conn, $_POST['name']);
$addr1 = mysqli_real_escape_string($conn, $_POST['addr1']);
$addr2 = mysqli_real_escape_string($conn, $_POST['addr2']);
$email = mysqli_real_escape_string($conn, $_POST['email']);

$sql = "INSERT INTO user (name, address1, address2, email) VALUES ('$fname', '$addr1','$addr2','$email')";

if(mysqli_query($conn, $sql)){
    echo "Records added successfully.";
} else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($conn);
}
 
// Close connection
mysqli_close($conn);
?>
