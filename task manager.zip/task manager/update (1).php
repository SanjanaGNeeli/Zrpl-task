<?php
@$cn = mysqli_connect("localhost","root","","test");
//creating form
if(isset($_POST['id'])){
$id=$_POST['id'];
$result=$cn->query("Select * from task where id='$id'");
$row=$result->fetch_assoc();
echo"<br><b>Update your record</b><br><br>Name: <input type='text' class='title' value='$row[title]'><br><br>
Address1: <input type=text class='upAddress1' value='$row[description]'><br><br>

<button class='upd' data-id='{$row["id"]}'>update</button>";
}
//update record
if(isset($_POST['fid'])){
	$fid = $_POST['fid'];
	$title = mysqli_real_escape_string($cn, $_POST['title']);
	$desc = mysqli_real_escape_string($cn, $_POST['decr']);
	date_default_timezone_get();
	$dat=date('y/m/d');
	$result=$cn->query("update task set title='$title',description='$desc',updated_at='$dat' where id='$fid'");
	echo"<script>alert('record updated');</script>";
}
?>