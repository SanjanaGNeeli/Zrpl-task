<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Add Record Form</title>
<script src="https://code.jquery.com/jquery-3.6.4.js"></script>
     
    <script>
    $(document).ready(function() {
        getalldata();
        function getalldata()
            {
                var response = '';
                $.ajax({
                   type: "GET",
                   url: "retrive.php",
                   async: true,
                   success: function(data) {
                    
                    $('#mydata').html(data);
                   }
                      })
        
           }         
    
       
       

    $(document).on("click", ".btn-del", function(){
            var uid=$(this).data("id");
            var elt=this
             $.ajax({
                url:"delete.php",
                type:"POST",
                data:{id:uid},
                success:function(data){
                    if(data==1)
                    {
                        alert("record deleted");
                        $(elt).closest("tr").fadeOut();
                    }
                    else{

                        $("#mydiv").text("Not able to delete");
                    }

                }

             });
        });
        $(document).on("click", ".btn-upd", function(){
            var uid=$(this).data("id");
            var elt=this
             $.ajax({
                url:"update.php",
                type:"POST",
                data:{id:uid},
                success:function(data){
                    $("#update").html(data);

                }

             });
        });
        $(document).on("click", ".upd", function(){
            var fid=$(this).data("id");
          
            var title = $('.title').val();
        
            var desc= $('.upAddress1').val();
         
            $.ajax({
                
                url:"update.php",
                type:"POST",
                data:{
                      title:title,
                      desc:desc,
                       
                  },
                  async: true,
                success:function(data){
                    alert("record updated");
                    location.reload(true);

                }

             });
        });
    });
    </script>
</head>
<body>

<table border="1">
        <tr>
            <th>ID</th>
            <th>Title</th>
            <th>Description</th>
            <th>Created_at</th>
            <th>Updated_at</th>
        </tr>
     
      <tbody id="mydata">

     </tbody>
     </table> 
     <div id="mydiv"></div>
	<div id="update"></div>
    
</body>
</html>
