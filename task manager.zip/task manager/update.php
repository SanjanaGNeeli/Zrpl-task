<?php
@$cn = mysqli_connect("localhost","root","","task_manager");
//creating form
if(isset($_POST['id'])){
$id=$_POST['id'];
echo $id;
$result=$cn->query("Select * from task where id='$id'");
$row=$result->fetch_assoc();
echo"<form method='post' action='abc.php'><br><b>Update your record</b><br><br>Title: <input type='text' name='title' value='$row[title]'><br><br>
description: <input type=text name='desc' value='$row[description]'><br><br>
<input type=hidden name='fid' value='$row[id]'>
<input type='submit' value='submit' name='submit'>";
}
//update record

?>