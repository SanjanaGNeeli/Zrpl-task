<?php
@$cn = mysqli_connect("localhost","root","","task_manager");

if(isset($_POST['submit'])){
	$fid = $_POST['fid'];
	
	$title = $_POST['title'];
	$desc = $_POST['desc'];
	date_default_timezone_get();
	$dat=date('y/m/d');
	$result=$cn->query("update task set title='$title',description='$desc',updated_at='$dat' where id='$fid'");
	if($result){
	echo"<script>alert('record updated');</script>";
}}
?>