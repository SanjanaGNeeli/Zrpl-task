<?php
    
    $con = mysqli_connect("localhost","root","","task_manager");
    
    $result= mysqli_query($con,"SELECT * FROM task");
    //$array = mysql_fetch_row($result);
?>
 
<?php
if (mysqli_num_rows($result) > 0) {
    while ($row = mysqli_fetch_assoc($result))
    {
        echo "<tr><td>" . $row["id"]. "</td><td>" . $row["title"] . "</td><td>"
. $row["description"]. "</td><td>" . $row["created_at"]. "</td><td>". $row["updated_at"]."</td><td><button class='btn-del' data-id='{$row["id"]}'>Delete</button>"."</td><td><button class='btn-upd' data-id='{$row["id"]}'>Update</button>"."</td></tr>";
    
    }   
}
else {
    echo "0 results";
}
//mysqli_close($conn);
?>
