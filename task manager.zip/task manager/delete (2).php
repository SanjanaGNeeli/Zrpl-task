<?php
    $userid=$_POST["id"];
    $con = mysqli_connect("localhost","root","","task_manager");
    $sql = "delete from task where id={$userid}";
    if(mysqli_query($con,$sql))
    {
        echo 1;
    }
    else{
        echo 0;
    }
    ?>
    