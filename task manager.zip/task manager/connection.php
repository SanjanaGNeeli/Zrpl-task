<?php
@$cn=new mysqli('localhost','root',' ','task_manager');


?>